#pragma once
#include<windows.h>
#include<iostream>
class draw
{
public:
	static void gotoxy(int x, int y) {
		COORD pos;
		HANDLE hOutput;
		pos.X = y;
		pos.Y = x;
		hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleCursorPosition(hOutput, pos);
	}
	static void printRow(int x, int y, int width, char ch = '*') {
		gotoxy(x, y);
		for (int i = 0; i < width; i++) {
			printf("%c", ch);
		}
	}
	static void printCol(int x, int y, int height, char ch = '*') {
		for (int i = 0; i < height; i++) {
			gotoxy(x + i, y);
			printf("%c", ch);
		}
	}
	static void printRect(int x, int y, int width, int height, char ch1 = '*', char ch2 = '*') {
		printRow(x, y, width, ch1);
		printRow(x + height - 1, y, width, ch1);
		printCol(x + 1, y, height - 2, ch2);
		printCol(x + 1, y + width - 1, height - 2, ch2);
	}
	static void drawFunction(int x, int y, const string functionName) {
		printRect(x - 1, y - 2, functionName.length() + 4, 3, '-', '|');
		gotoxy(x, y);
		printf("%s", functionName.c_str());
	}
	static void drawTitle(int x, int y, const string title) {
		gotoxy(x, y);
		printf("%s", title.c_str());
	}
	static void clearWidget(int x, int y, int width, int height) {
		for (int i = x + 1; i < x + height - 1; i++) {
			gotoxy(i, y + 1);
			printf("%*c", width - 2, ' ');
		}
	}
	static void printAddIntro(int x,int y) {		
		drawTitle(x + 1, y + 1, "������Ҫ���ӵĸ�����Ϣ:");
		drawTitle(x + 2, y + 2, "������    :");
		drawTitle(x + 3, y + 2, "����      :");
		drawTitle(x + 4, y + 2, "��������д:");
	}
	static void printSearchIntro(int x, int y) {
		drawTitle(x + 1, y + 1, "��ѡ����ҷ�ʽ");
		drawTitle(x + 3, y + 5, "����������");
		drawTitle(x + 4, y + 5, "�����ֲ���");
	}
	static void printDeleteIntro(int x, int y) {
		
	}
	static void clearRow(int x, int y, int width) {
		draw::gotoxy(x, y);
		printf("%*c", width, ' ');
	}
	static void cerrWidgetBottom(int x, int y, int width, int height, string errInfo) {
		int start_x = x + height - 2;
		int start_y = y + width / 2 - 8;
		clearRow(start_x, start_y, 24);
		drawTitle(start_x, start_y, errInfo);
	}
	static void printModifyInfo(int x, int y, Music &m) {
		drawTitle(x + 1, y + 1, "���޸ĸ�����Ϣ:");
		gotoxy(x + 2, y + 2);
		printf("%s ->", m.name.c_str());
		gotoxy(x + 3, y + 2);
		printf("%s ->", m.singer.c_str());
		gotoxy(x + 4, y + 2);
		printf("%s ->", m.abb.c_str());
	}
	static void printMarkInfo(int x,int y) {
		drawTitle(x - 1, y, "����ø������:");
		drawTitle(x, y + 3, "������");
	}
	static void starHightlight(int x, int y) {
		gotoxy(x, y);
		printf("��");
	}
	static void starHide(int x, int y) {
		gotoxy(x, y);
		printf("��");
	}
};