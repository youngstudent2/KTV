#pragma once
#include"TcpClient.h"
#include<iostream>
#include<string>
#include<thread>
#include"Info.h"
#include"InputHandle.h"
#include"Draw.h"
using namespace std;
/***************��Ϣ��ť����****************/
HHOOK hHook2;
LRESULT __stdcall CBTHookProc2(long nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode == HCBT_ACTIVATE)
	{
		SetDlgItemText((HWND)wParam, IDYES, "�����ֲ���");
		SetDlgItemText((HWND)wParam, IDNO, "����������");
		//SetDlgItemText((HWND)wParam, ID, "����������");
		UnhookWindowsHookEx(hHook2);
	}
	return 0;
}
/***********************************/

class ClientLayout
{
public:
	ClientLayout() {
		connected = 0;
		playMusic = 0;
		playMusics.loadFile("music.txt");
		if (playMusics.musics_count() > 0)playEmpty = false;
		musicBank.loadFile("music.txt");
	}
	int exec() {		
		//get_IP();
		render();
		//tcpThread = thread(&ClientLayout::tcpRequest, this);
		//tcpThread.join();
		//////////�������server�����ʺ�
		//draw::gotoxy(39, 5);
		//cout << tcpClient.getGreetWord();
		//////////////////////////////
		currPage = 0;
		printPage(currPage, playMusics, 0, playMusic + 1);
		//detailWidgetInit();
		int choice = 0;
		currMusic = 0;
		MusicHighlight(currMusic);
		choiceHighlight(choice);
		while (1) {
			switch (InputHandle::getKeyInput())
			{
			case InputHandle::KEY_UP:
			case InputHandle::KEY_LEFT:
				choiceUp(choice);
				break;
			case InputHandle::KEY_DOWN:
			case InputHandle::KEY_RIGHT:
				choiceDown(choice);
				break;
			case InputHandle::KEY_ENTER:
				chooseFunction(choice);
				break;
			case InputHandle::KEY_Q://��һҳ
				printPage(--currPage, playMusics, 0, playMusic + 1);
				
				break;
			case InputHandle::KEY_E://��һҳ
				printPage(++currPage, playMusics, 0, playMusic + 1);
		
				break;
			case InputHandle::KEY_W:
				MusicUp(currMusic);
				
				break;
			case InputHandle::KEY_S:
				MusicDown(currMusic);
				break;
			case InputHandle::CTRL_N://�и�
				nextMusic();
				break;
			case InputHandle::ESC://���淵��
				return -1;
				break;
			case InputHandle::CTRL_Z://����
				mark();
				break;
			case InputHandle::CTRL_D://ɾ��
				playMusics.eraseMusic(currMusic + currPage * musicNum + playMusic + 1);
				printPage(currPage, playMusics, 0, playMusic + 1);
				break;
			case InputHandle::CTRL_T://�ö�
				putOnTop();
				break;
			default:
				break;
			}
		}
		return 1;
	}
private:
	Info playMusics;
	Info musicBank;
	int page, currPage;
	int currMusic;
	int playMusic;
	static const int SCORE_START = 86;
	static const int ID_START = 95;
	static const int NAME_START = 104;
	static const int SINGER_START = 130;
	static const int SINGER_END = 140;

	void render() {
		system("cls");
		system("color 0B");
		draw::printRect(2, 5, 140, 35);

		drawWidget();
		printFunction();
		
	}
	void drawWidget()
	{
		draw::gotoxy(3, SCORE_START + 12);
		cout << "�ѵ����";
		draw::printRow(4, SCORE_START + 8, 18);
		draw::drawTitle(9, SCORE_START + 1, "����");
		draw::drawTitle(9, ID_START + 1, "���");
		draw::drawTitle(9, NAME_START + 8, "������");
		draw::drawTitle(9, SINGER_START + 2, "����");
		draw::drawTitle(5, SCORE_START , "���ڲ���:");

		printPlayMusic();
		for (int i = 0; i <= musicNum; i++) {
			draw::printRow(10 + i * 2, SCORE_START, SINGER_END - SCORE_START + 1, '-');
		}

		draw::printCol(9, SCORE_START, musicNum * 2 + 2, '|');
		draw::printCol(9, ID_START, musicNum * 2 + 1, '|');
		draw::printCol(9, NAME_START, musicNum * 2 + 1, '|');
		draw::printCol(9, SINGER_START, musicNum * 2 + 1, '|');
		draw::printCol(9, SINGER_END, musicNum * 2 + 1, '|');
	}
	void printFunction() {
		draw::printRect(6, 20, 40, 10);
		draw::drawTitle(11, 34, "�����Ƽ�");
		draw::printRect(20, 20, 40, 10);
		draw::drawTitle(25, 34, "������");
		
	}
	void clearFuntion() {
		draw::clearWidget(5, 19, 42, 32);
	}
	/*******************���ܼ�����ƶ�*********************/
	static const int choiceNum = 2;
	void choiceUp(int &choice) {
		choiceHide(choice);
		choice--;
		if (choice < 0)choice += choiceNum;
		choiceHighlight(choice);
	}
	void choiceDown(int &choice) {
		choiceHide(choice);
		choice++;
		if (choice >= choiceNum)choice = 0;
		choiceHighlight(choice);
	}
	void choiceHighlight(int choice) {
		draw::printRect(10 + choice * 14, 32, 12, 3, '-', '|');
	}
	void choiceHide(int choice) {
		draw::printRect(10 + choice * 14, 32, 12, 3, ' ', ' ');
	}
	/*****************************************/

	/*******************���ֹ���ƶ�*********************/
	const int musicNum = 12;
	void MusicUp(int &choice, int y = SCORE_START - 3) {
		MusicHide(choice, y);
		choice--;
		if (choice < 0)choice += musicNum;
		MusicHighlight(choice, y);
	}
	void MusicDown(int &choice, int y = SCORE_START - 3) {
		MusicHide(choice, y);
		choice++;
		if (choice >= musicNum)choice = 0;
		MusicHighlight(choice, y);
	}
	void MusicHighlight(int choice, int y = SCORE_START - 3) {
		draw::gotoxy(11 + choice * 2, y);
		printf("->");
	}
	void MusicHide(int choice, int y = SCORE_START - 3) {
		draw::gotoxy(11 + choice * 2, y);
		printf("  ");
	}
	void MusicJump(int index) {
		if (index < currPage * musicNum || index>(currPage + 1) * musicNum) {
			currPage = index / musicNum;
			printPage(currPage, playMusics);
		}
		MusicHide(currMusic);
		currMusic = index % musicNum;
		MusicHighlight(currMusic);
	}
	/*****************************************/
	//CRITICAL_SECTION g_cs;
	void printPage(int &currPage, Info &info, int dis = 0, int playMusic = 0) {
		this->page = (info.musics_count() - 1 - playMusic) / musicNum;
		if (currPage < 0)currPage = page;
		if (currPage > this->page)currPage = 0;

		//eraseAll();
		printMusics(playMusic + musicNum * currPage, musicNum, info, dis);
	}
	void printMusics(int begin, int count, Info &info, int dis = 0) {
		//vector<thread> printThreads;
		for (int i = 0; i < count; i++) {
			if (i + begin < info.musics_count()) {
				//printThreads.push_back(thread(&AdminLayout::printMusic, this, 7 + i * 2, i + begin));				
				//printThreads.back().join();
				printMusic(11 + i * 2, i + begin, info, dis);
			}
			else {
				erase(11 + i * 2, dis);
			}
		}
	}
	void printMusic(int x, int index, Info &info, int dis = 0) {
		//EnterCriticalSection(&g_cs);
		Music m = info.getMusic(index);
		draw::gotoxy(x, SCORE_START + 1 - dis);
		printf("%-*.1f", ID_START - SCORE_START - 1, m.score);
		//cout << std::left << setw(ID_START - SCORE_START - 1) << m.score;
		draw::gotoxy(x, ID_START + 1 - dis);
		printf("%-*d", NAME_START - ID_START - 1, m.ID);
		//cout << std::left << setw(NAME_START - ID_START - 1) << m.ID;
		draw::gotoxy(x, NAME_START + 1 - dis);
		printf("%-*s", SINGER_START - NAME_START - 1, m.name.c_str());
		//cout << std::left << setw(SINGER_START - NAME_START - 1) << m.name;
		draw::gotoxy(x, SINGER_START + 1 - dis);
		printf("%-*s", SINGER_END - SINGER_START - 1, m.singer.c_str());
		//LeaveCriticalSection(&g_cs);
		//cout << std::left << setw(SINGER_END - SINGER_START - 1) << m.singer;
	}
	static void erase(int x, int dis = 0) {
		//EnterCriticalSection(&g_cs);
		draw::gotoxy(x, SCORE_START + 1 - dis);
		printf("%-*c", ID_START - SCORE_START - 1, ' ');
		//cout << setfill(' ') << setw(ID_START - SCORE_START - 1) << ' ';
		draw::gotoxy(x, ID_START + 1 - dis);
		printf("%-*c", NAME_START - ID_START - 1, ' ');
		//cout << setw(NAME_START - ID_START - 1) << ' ';
		draw::gotoxy(x, NAME_START + 1 - dis);
		printf("%-*c", SINGER_START - NAME_START - 1, ' ');
		//cout << setw(SINGER_START - NAME_START - 1) << ' ';
		draw::gotoxy(x, SINGER_START + 1 - dis);
		printf("%-*c", SINGER_END - SINGER_START - 1, ' ');
		//cout << setw(SINGER_END - SINGER_START - 1) << ' ';
		//LeaveCriticalSection(&g_cs);
	}
	
	void printPlayMusic() {
		playMusics.setMusicState(playMusic, 0);
		Music m = playMusics.getMusic(playMusic);
		if (m.ID == -1)return;
		draw::drawTitle(6, SCORE_START + 5, m.name);
		draw::drawTitle(7, SCORE_START + 5, m.singer);
	}
	
	void chooseFunction(int choice) {
		switch (choice)
		{

		case 0://���Ÿ���
			hotMusics();
			break;
		case 1://������
			vod();
			break;
		default:
			break;
		}
	}

	/********************��Ҫ���ܵ�ʵ��*******************************/
	void hotMusics() {

	}
	const int DISTANCE = 74;
	void vod() {
		int bankPage = 0;
		int currBankMusic = 0;
		clearFuntion();
		for (int i = 0; i <= musicNum; i++) {
			draw::printRow(10 + i * 2, SCORE_START - DISTANCE, SINGER_END - SCORE_START + 1, '-');
		}

		draw::printCol(10, SCORE_START - DISTANCE, musicNum * 2 + 1, '|');
		draw::printCol(10, ID_START - DISTANCE, musicNum * 2 + 0, '|');
		draw::printCol(10, NAME_START - DISTANCE, musicNum * 2 + 0, '|');
		draw::printCol(10, SINGER_START - DISTANCE, musicNum * 2 + 0, '|');
		draw::printCol(10, SINGER_END - DISTANCE, musicNum * 2 + 0, '|');
		draw::drawTitle(4, 7, "����:ctrl+F");
		//InputHandle::getString(5, 11);
		printPage(bankPage, musicBank, DISTANCE);
		MusicHide(currMusic);
		MusicHighlight(currBankMusic, SCORE_START - DISTANCE - 3);
		while (1) {
			switch (InputHandle::getKeyInput())
			{
			case InputHandle::KEY_UP:
				MusicUp(currBankMusic, SCORE_START - DISTANCE - 3);
				break;
			case InputHandle::KEY_LEFT://��һҳ
				printPage(--bankPage, musicBank, DISTANCE);
				break;
			case InputHandle::KEY_DOWN:
				MusicDown(currBankMusic, SCORE_START - DISTANCE - 3);
				break;
			case InputHandle::KEY_RIGHT://��һҳ
				printPage(++bankPage, musicBank, DISTANCE);
				break;
			case InputHandle::ESC:
				draw::clearWidget(3, 6, 65, 33);
				printFunction();
				choiceHighlight(1);
				MusicHighlight(currMusic);
				return;
				break;
			case InputHandle::KEY_Q:
				
				break;
			case InputHandle::KEY_E:
				
				break;
			case InputHandle::KEY_W:
				
				break;
			case InputHandle::KEY_S:
				
				break;
			case InputHandle::CTRL_N://���
				clickMusic(currBankMusic + bankPage * musicNum);
				break;
			case InputHandle::CTRL_T://
				musicBank.setTmpState(false);
				currBankMusic = 0;
				bankPage = 0;
				printPage(bankPage, musicBank, DISTANCE);
				break;
			case InputHandle::CTRL_F://����
				if (search()) {
					//currBankMusic = 0;
					bankPage = 0;
					printPage(bankPage, musicBank, DISTANCE);
				}		
				else {
					draw::drawTitle(8, 8, "no found");
					Sleep(500);
				}
				draw::clearRow(6, 8, 20);
				draw::clearRow(7, 8, 20);
				draw::clearRow(8, 8, 20);
				break;
			default:
				break;
			}
		}
	}
	void clickMusic(int index) {
		playMusics.add(musicBank.getMusic(index));
		currPage = page;
		currMusic = 0;
		if (playEmpty) {
			nextMusic();
			playEmpty = false;
			//playMusics.nextMusic(playMusic);

		}
		printPage(currPage, playMusics, 0, playMusic + 1);
		
	}
	int search() {
		hHook2 = SetWindowsHookEx(WH_CBT, (HOOKPROC)CBTHookProc2, NULL, GetCurrentThreadId());
		int MB_RES = MessageBox(GetForegroundWindow(), "��ѡ����ҷ�ʽ", "ѡ��", 3);
		if (MB_RES == 6) {//���Ҹ���
			draw::drawTitle(6, 8, "������Ҫ���ҵĸ���");
			return musicBank.singerSearch(InputHandle::getString(7, 8));
		}
		else if (MB_RES == 7) {//���Ҹ���
			draw::drawTitle(6, 8, "������Ҫ���ҵĸ���");
			return musicBank.musicSearch(InputHandle::getString(7, 8));
		}
		else {
			return 0;
		}
		
	}
	bool playEmpty;
	void nextMusic() {		
		draw::clearRow(6, SCORE_START + 4, 20);
		draw::clearRow(7, SCORE_START + 4, 20);
		if (playMusic >= playMusics.musics_count() - 1) { 
			playEmpty = true;
			return;
		}
		playMusics.nextMusic(playMusic);
		printPlayMusic();
		printPage(currPage, playMusics, 0, playMusic + 1);
	}
	void putOnTop() {
		int index = playMusic + 1 + currPage * musicNum + currMusic;
		Music m = playMusics.getMusic(index);
		if (m.ID == -1)return;
		if (MessageBox(NULL, string("Ҫ�Ѹ�����" + m.name + "  �ö���").c_str(), "�ö�", 1) == 2)return;
		playMusics.eraseMusic(index);
		playMusics.insert(m, playMusic + 1);
		refresh2();
	}
	void mark() {
		int index = playMusic + 1 + currPage * musicNum + currMusic;
		Music m = playMusics.getMusic(index);
		if (m.ID == -1)return;

		MusicHide(currMusic);
		draw::printMarkInfo(11 + currMusic * 2, SCORE_START - 16);
		int score = 0;
		int x_s = 11 + currMusic * 2;
		int y_s = SCORE_START - 15;
		while (1) {
			switch (InputHandle::getKeyInput())
			{
			case InputHandle::KEY_LEFT:
				if (score > 0) {			
					draw::starHide(x_s, y_s + score * 2);
					score--;
				}

				break;
			case InputHandle::KEY_RIGHT:
				if (score < 5) {
					score++;
					draw::starHightlight(x_s, y_s + score * 2);
				}
				break;
			case InputHandle::ESC:
				draw::clearRow(10 + currMusic * 2, SCORE_START - 16, 16);
				draw::clearRow(11 + currMusic * 2, SCORE_START - 16, 16);
				return;
				break;
			case InputHandle::KEY_ENTER:
				playMusics.markMusic(index, score);
				printPage(currPage, playMusics, 0, playMusic + 1);
				draw::clearRow(10 + currMusic * 2, SCORE_START - 16, 16);
				draw::clearRow(11 + currMusic * 2, SCORE_START - 16, 16);
				MusicHighlight(currMusic);
				return;
				break;
			default:
				break;
			}
		}
	}

	void refresh() {
		playMusics.clear();
		tcpThread = thread(&ClientLayout::tcpRequest, this);
		tcpThread.join();
		if (connected) {
			this->currPage = 0;
			printPage(this->currPage, musicBank);
		}
	}
	void refresh2() {
		currPage = 0;
		MusicHide(currMusic);
		currMusic = 0;
		printPage(currPage, playMusics, 0, playMusic + 1);
	}

	/******************************************************************/

	/************************С����չ����************************************/
	
	
	/***************************************************************/
	string ip;
	TcpClient tcpClient;
	thread tcpThread;
	string greetWord;
	volatile int connected;
	void get_IP() {
		system("cls");
		cout << "please input the server ip:";
		cin >> ip;
	}
	void tcpRequest() {
		string temp;
		while (!tcpClient.init(ip)) {
			connected = 0;
			Sleep(200);
		}
		connected = 1;

		greetWord = tcpClient.getGreetWord();

		temp = tcpClient.recvMessage();
		while (temp != "EOF") {			
			if (temp != "error") {
				musicBank.tcpAssist(temp);
			}	
			temp = tcpClient.recvMessage();
		}
		tcpClient.close();	
		
	}
	
};