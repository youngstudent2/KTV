#pragma once
#include"TcpServer.h"
#include"Info.h"
#include"Draw.h"
#include<iostream>
#include"InputHandle.h"
#include<thread>


/***************��Ϣ��ť����****************/
HHOOK hHook;
LRESULT __stdcall CBTHookProc(long nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode == HCBT_ACTIVATE)
	{
		SetDlgItemText((HWND)wParam, IDYES, "����");
		SetDlgItemText((HWND)wParam, IDNO, "����Ϊ");
		UnhookWindowsHookEx(hHook);
	}
	return 0;
}
/***********************************/using namespace std;
class AdminLayout
{
public:
	AdminLayout() {
		info.loadFile("music.txt");
		saved = true;
		//tcpThread = thread(&AdminLayout::tcpServe, this);	
	}

	int exec() {
		render();
		//isRunning = true;
		//tcpThread.detach();
		detailWidgetInit();
		int choice=0;
		currMusic = 0;
		//printHotelRooms(info.getHotel(currHotel + currPage * 14));
		MusicHighlight(currMusic);
		choiceHighlight(choice);
		while (1) {		
			switch (InputHandle::getKeyInput())
			{
				case InputHandle::KEY_UP:
				case InputHandle::KEY_LEFT:
					choiceUp(choice);
					break;
				case InputHandle::KEY_DOWN:
				case InputHandle::KEY_RIGHT:
					choiceDown(choice);
					break;
				case InputHandle::KEY_ENTER:
					chooseFunction(choice);
					break;
				case InputHandle::KEY_Q://��һҳ
					printPage(--currPage);
		
					break;
				case InputHandle::KEY_E://��һҳ
					printPage(++currPage);
	
					break;
				case InputHandle::KEY_W:
					MusicUp(currMusic);
					
					break;
				case InputHandle::KEY_S:
					MusicDown(currMusic);
			
					break;
				case InputHandle::ESC:  //���淵��
					if (!saved) {
						if (MessageBox(NULL, " �Ƿ񱣴棿", "δ����", 1) == 1) {
							info.saveInfo("music.txt");
						}
					}
					return -1;
					break;
				case InputHandle::CTRL_D:  //ɾ��
					deleteMusic();
					break;
				case InputHandle::CTRL_F:  //����
					search();
					break;
				case InputHandle::CTRL_T:  //ˢ��
					info.setTmpState(false);
					refresh();
					break;
				case InputHandle::CTRL_S:  //����
					if (!saved) {
						info.saveInfo("music.txt");
						MessageBox(NULL, "����ɹ�", "����", MB_OK);
					}
					break;
				default:
					break;
			}
		}
		return 1;
	}
	~AdminLayout() {
		isRunning = false;
		info.~Info();
		tcpThread.~thread();
	}
private:
	Info info;
	int page, currPage;
	int currMusic;
	bool saved;
	static const int SCORE_START = 6;
	static const int ID_START = 15;
	static const int NAME_START = 24;
	static const int SINGER_START = 50;
	static const int SINGER_END = 60;
	static const int FUNCTION_Y = 72;
	void render() {
		system("cls");
		system("color 0B");
		draw::printRect(2, 5, 140, 35);
		drawFunctionWidget();
		drawWidget();
		printFunction();
		currPage = 0;
		printPage(currPage);
	}
	void drawWidget()
	{
		draw::gotoxy(3, 48);
		cout << "KTV����";
		draw::printRow(4, 44, 18);
		draw::drawTitle(5, SCORE_START + 1, "����");
		draw::drawTitle(5, ID_START + 1, "���");
		draw::drawTitle(5, NAME_START + 8, "������");
		draw::drawTitle(5, SINGER_START + 2, "����");

		for (int i = 0; i < 15; i++) {
			draw::printRow(6 + i * 2, 6, SINGER_END - SCORE_START + 1, '-');
		}

		draw::printCol(5, SCORE_START, 30, '|');
		draw::printCol(5, ID_START, 29, '|');
		draw::printCol(5, NAME_START, 29, '|');
		draw::printCol(5, SINGER_START, 29, '|');
		draw::printCol(5, SINGER_END, 29, '|');
	}
	void printFunction() {
		draw::drawFunction(14, FUNCTION_Y, "��������");
		draw::drawFunction(18, FUNCTION_Y, "��������");
		draw::drawFunction(22, FUNCTION_Y, "����");
		draw::drawFunction(26, FUNCTION_Y, "�޸�");
		draw::drawFunction(30, FUNCTION_Y, "����");
		draw::drawFunction(34, FUNCTION_Y, "����");
		//draw::drawFunction(34, FUNCTION_Y, "����");
	}
	/*******************���ܼ�����ƶ�*********************/
	static const int choiceNum = 6;
	void choiceUp(int &choice) {
		choiceHide(choice);
		choice--;
		if (choice < 0)choice += choiceNum;
		choiceHighlight(choice);
	}
	void choiceDown(int &choice) {
		choiceHide(choice);
		choice++;
		if (choice >= choiceNum)choice = 0;
		choiceHighlight(choice);
	}
	void choiceHighlight(int choice) {
		draw::gotoxy(14 + choice * 4, FUNCTION_Y - 3);
		cout << '#';
	}
	void choiceHide(int choice) {
		draw::gotoxy(14 + choice * 4, FUNCTION_Y - 3);
		cout << ' ';
	}
	/*****************************************/

	/*******************���ֹ���ƶ�*********************/
	void MusicUp(int &choice) {
		MusicHide(choice);
		choice--;
		if (choice < 0)choice += 14;
		MusicHighlight(choice);
	}
	void MusicDown(int &choice) {
		MusicHide(choice);
		choice++;
		if (choice > 13)choice = 0;
		MusicHighlight(choice);
	}
	void MusicHighlight(int choice) {
		draw::gotoxy(7 + choice * 2, 2);
		cout << '@';
	}
	void MusicHide(int choice) {
		draw::gotoxy(7 + choice * 2, 2);
		cout << ' ';
	}
	void MusicJump(int index) {
		if (index < currPage * 14 || index>=(currPage + 1) * 14) {
			currPage = index / 14;
			//printPage(currPage);
		}
		MusicHide(currMusic);
		currMusic = index % 14;
		MusicHighlight(currMusic);
	}
	/*****************************************/
	CRITICAL_SECTION g_cs;
	void printPage(int &currPage) {
		this->page = (info.musics_count() - 1) / 14;
		if (currPage < 0)currPage = page;
		if (currPage > this->page)currPage = 0;

		//eraseAll();
		printMusics(14 * currPage, 14);
	}
	void printMusics(int begin,int count) {
		//vector<thread> printThreads;
		//InitializeCriticalSection(&g_cs);
		for (int i = 0; i < count; i++) {
			if (i + begin < info.musics_count()) {
				//printThreads.push_back(thread(&AdminLayout::printMusic, this, 7 + i * 2, i + begin));				
				printMusic(7 + i * 2, i + begin);
			}
			else {
				//printThreads.push_back(thread(&AdminLayout::erase, this, 7 + i * 2));
				erase(7 + i * 2);
			}
		}
		/*
		for (auto &t : printThreads) {
			t.join();
		}*/
	}
	void printMusic(int x,int index) {
		//EnterCriticalSection(&g_cs);
		Music m = info.getMusic(index);
		draw::gotoxy(x, SCORE_START + 1);
		printf("%-*.1f", ID_START - SCORE_START - 1, m.score);
		//cout << std::left << setw(ID_START - SCORE_START - 1) << m.score;
		draw::gotoxy(x, ID_START + 1);
		printf("%-*d", NAME_START - ID_START - 1, m.ID);
		//cout << std::left << setw(NAME_START - ID_START - 1) << m.ID;
		draw::gotoxy(x, NAME_START + 1);
		printf("%-*s", SINGER_START - NAME_START - 1, m.name.c_str());
		//cout << std::left << setw(SINGER_START - NAME_START - 1) << m.name;
		draw::gotoxy(x, SINGER_START + 1);
		printf("%-*s", SINGER_END - SINGER_START - 1, m.singer.c_str());
		//LeaveCriticalSection(&g_cs);
		//cout << std::left << setw(SINGER_END - SINGER_START - 1) << m.singer;
	}
	void erase(int x) {
		//EnterCriticalSection(&g_cs);
		draw::gotoxy(x, SCORE_START + 1);
		printf("%-*c", ID_START - SCORE_START - 1, ' ');
		//cout << setfill(' ') << setw(ID_START - SCORE_START - 1) << ' ';
		draw::gotoxy(x, ID_START + 1);
		printf("%-*c", NAME_START - ID_START - 1, ' ');
		//cout << setw(NAME_START - ID_START - 1) << ' ';
		draw::gotoxy(x, NAME_START + 1);
		printf("%-*c", SINGER_START - NAME_START - 1, ' ');
		//cout << setw(SINGER_START - NAME_START - 1) << ' ';
		draw::gotoxy(x, SINGER_START + 1);
		printf("%-*c", SINGER_END - SINGER_START - 1, ' ');
		//cout << setw(SINGER_END - SINGER_START - 1) << ' ';
		//LeaveCriticalSection(&g_cs);
	}
	/*
	void eraseAll() {
		thread eraseThread[15];
		for (int i = 0; i < 14; i++) {
			eraseThread[i].~thread();
			eraseThread[i] = thread(AdminLayout::erase,7 + i * 2);			
		}
		for (int i = 0; i < 14; i++) {
			eraseThread[i].join();
		}
	}
	*/
	void chooseFunction(int choice) {
		switch (choice)
		{
			case 0://��������
				rank();
				break;
			case 1://��������

				break;
			case 2://����
				add();
				printPage(currPage);//ˢ��
				break;
			case 3://�޸�
				modify();
				break;
			case 4://����
				search();		
				break;
			case 5://����
				save();
				break;
			
			default:
				break;
		}
	}
	
	/********************��Ҫ���ܵ�ʵ��*******************************/
	void rank() {
		info.rankMusics();
		refresh();
	}
	void add() {
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		draw::printAddIntro(FunctionWidget_X, FunctionWidget_Y);
		string name, singer, abb;
		while (1) {
			name = InputHandle::getString(FunctionWidget_X + 2, FunctionWidget_Y + 13);
			if (name.length() > 1 && name.length() < 20) {
				break;
			}
			else {
				draw::cerrWidgetBottom(FunctionWidget_X,
					FunctionWidget_Y,
					FunctionWidget_WIDTH,
					FunctionWidget_HEIGHT,
					"���������벻�Ϸ�");
				draw::clearRow(FunctionWidget_X + 2, FunctionWidget_Y + 13, 30);
			}
		}
		while (1) {
			singer = InputHandle::getString(FunctionWidget_X + 3, FunctionWidget_Y + 13);
			if (singer.length() > 1 && singer.length() < 20) {
				break;
			}
			else {
				draw::cerrWidgetBottom(FunctionWidget_X,
					FunctionWidget_Y,
					FunctionWidget_WIDTH,
					FunctionWidget_HEIGHT,
					"���������벻�Ϸ�");
				draw::clearRow(FunctionWidget_X + 3, FunctionWidget_Y + 13, 30);
			}
		}
		while (1) {
			abb = InputHandle::getString(FunctionWidget_X + 4, FunctionWidget_Y + 13);
			if (abb.length() > 1 && abb.length() < 20) {
				break;
			}
			else {
				draw::cerrWidgetBottom(FunctionWidget_X,
					FunctionWidget_Y,
					FunctionWidget_WIDTH,
					FunctionWidget_HEIGHT,
					"���������벻�Ϸ�");
				draw::clearRow(FunctionWidget_X + 4, FunctionWidget_Y + 13, 30);
			}
		}
		if (info.add(info.createMusic(name, singer, abb))) {
			draw::cerrWidgetBottom(FunctionWidget_X,
				FunctionWidget_Y,
				FunctionWidget_WIDTH,
				FunctionWidget_HEIGHT,
				"�������ӳɹ�");
		}
		else {
			draw::cerrWidgetBottom(FunctionWidget_X,
				FunctionWidget_Y,
				FunctionWidget_WIDTH,
				FunctionWidget_HEIGHT,
				"�ø����Ѵ���");
		}
		Sleep(300);
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		
		saved = false;
	}

	void modify() {
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		Music m(info.getMusic(currMusic + currPage * 14));
		draw::printModifyInfo(FunctionWidget_X, FunctionWidget_Y, m);
		string name = InputHandle::getString(FunctionWidget_X + 2, FunctionWidget_Y + m.name.length() + 6);
		string singer = InputHandle::getString(FunctionWidget_X + 3, FunctionWidget_Y + m.singer.length() + 6);
		string abb = InputHandle::getString(FunctionWidget_X + 4, FunctionWidget_Y + m.abb.length() + 6);
		if (!name.empty())m.name = name;
		if (!singer.empty())m.singer = singer;
		if (!abb.empty())m.abb = abb;
		info.eraseMusic(currMusic + currPage * 14);
		info.insert(m, currMusic + currPage * 14);
		saved = false;
		draw::cerrWidgetBottom(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT,
			"�޸ĳɹ�");
		Sleep(500);

		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		printPage(currPage);
	}

	void search() {
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		int searchChoice = 0;
		draw::printSearchIntro(FunctionWidget_X, FunctionWidget_Y);
		searchChoiceHighlight(searchChoice);
		while (1) {
			switch (InputHandle::getKeyInput())
			{
			case InputHandle::KEY_UP:
				searchChoiceUp(searchChoice);
				break;
			case InputHandle::KEY_DOWN:
				searchChoiceDown(searchChoice);
				break;
			case InputHandle::KEY_ENTER:
				if (searchChoice == 0)search_by_name();
				if (searchChoice == 1)search_by_singer();
				draw::clearWidget(FunctionWidget_X,
					FunctionWidget_Y,
					FunctionWidget_WIDTH,
					FunctionWidget_HEIGHT);
				return;
				break;

			}
		}
	}
	void searchChoiceUp(int &choice) {
		searchChoiceHide(choice);
		choice--;
		if (choice < 0)choice += 2;
		searchChoiceHighlight(choice);
	}
	void searchChoiceDown(int &choice) {
		searchChoiceHide(choice);
		choice++;
		if (choice >= 2)choice = 0;
		searchChoiceHighlight(choice);
	}
	void searchChoiceHighlight(int choice) {
		draw::gotoxy(FunctionWidget_X + 3 + choice, FunctionWidget_Y + 3);
		cout << '*';
	}
	void searchChoiceHide(int choice) {
		draw::gotoxy(FunctionWidget_X + 3 + choice, FunctionWidget_Y + 3);
		cout << ' ';
	}
	int search_by_singer() {
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		draw::drawTitle(FunctionWidget_X + 1, FunctionWidget_Y + 1, "������Ҫ���ҵĸ�������");
		string singer = InputHandle::getString(FunctionWidget_X + 2, FunctionWidget_Y + 14);
		info.singerSearch(singer);
		refresh();
		return 1;
	}
	int search_by_name() {
		draw::clearWidget(FunctionWidget_X,
			FunctionWidget_Y,
			FunctionWidget_WIDTH,
			FunctionWidget_HEIGHT);
		draw::drawTitle(FunctionWidget_X + 1, FunctionWidget_Y + 1, "������Ҫ���ҵĸ�����(����д)��");
		string name = InputHandle::getString(FunctionWidget_X + 2, FunctionWidget_Y + 14);
		info.musicSearch(name);
		refresh();
		return 1;
	}

	void save() {
		hHook = SetWindowsHookEx(WH_CBT, (HOOKPROC)CBTHookProc, NULL, GetCurrentThreadId());
		int MB_RES = MessageBox(NULL, "ѡ�񱣴淽ʽ", "����", 3);
		if (MB_RES == 6) {
			info.saveInfo("music.txt");
			MessageBox(NULL, TEXT("����ɹ�"), TEXT("����"), 0);
			saved = true;
		}
		else if (MB_RES == 7) {
			OPENFILENAME ofn = { 0 };
			TCHAR strFilename[MAX_PATH] = "music.txt";//���ڽ����ļ���
			ofn.lStructSize = sizeof(OPENFILENAME);//�ṹ���С
			ofn.hwndOwner = NULL;//ӵ���Ŵ��ھ����ΪNULL��ʾ�Ի����Ƿ�ģ̬�ģ�ʵ��Ӧ����һ�㶼Ҫ��������
			ofn.lpstrFilter = TEXT("�����ļ�\0*.*\0C/�ı��ĵ�\0*.txt\0\0");//���ù���
			ofn.nFilterIndex = 1;//����������
			ofn.lpstrFile = strFilename;//���շ��ص��ļ�����ע���һ���ַ���ҪΪNULL
			ofn.nMaxFile = sizeof(strFilename);//����������
			ofn.lpstrInitialDir = NULL;//��ʼĿ¼ΪĬ��
			ofn.lpstrTitle = TEXT("");//ʹ��ϵͳĬ�ϱ������ռ���
			ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;//�ļ���Ŀ¼������ڣ�����ֻ��ѡ��
			ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;//Ŀ¼������ڣ������ļ�ǰ��������
			ofn.lpstrTitle = TEXT("���浽");//ʹ��ϵͳĬ�ϱ������ռ���
			ofn.lpstrDefExt = TEXT("cpp");//Ĭ��׷�ӵ���չ��
			if (GetSaveFileName(&ofn))
			{
				info.saveInfo(strFilename);
				MessageBox(NULL, TEXT("����ɹ�"), TEXT("����"), 0);
				saved = true;
			}
			else {
				//ȡ������Ϊ
			}
		}
		else {

		}


	}

	void deleteMusic() {
		int sure;
		string cont = "����ɾ��:" + info.getMusic(currMusic + currPage * 14).name;
		if (cont.empty()) {
			MessageBox(GetForegroundWindow(), " û�иø���", "", 1); 
			return;
		}
		sure = MessageBox(GetForegroundWindow(), cont.c_str(), "ȷ��ɾ���ø�����", 1);
		if (sure == 1) {
			if (info.deleteMusic(currMusic + currPage * 14)) {
				printPage(currPage);
				saved = false;
			}
			else {
				MessageBox(GetForegroundWindow(), " û�иø���", "", 1);
			}
		}
	}

	void refresh() {
		currPage = 0;
		MusicHide(currMusic);
		currMusic = 0;
		MusicHighlight(currMusic);
		printPage(currPage);
	}
	/******************************************************************/

	/************************�����û�С��************************************/
	void detailWidgetInit() {
		draw::printRect(4, 85, 55, 10);
		draw::drawTitle(5, 90, "�������û�");
	}
	
	/***************************************************************/

	/***************************�������봰��********************************/
	static const int FunctionWidget_X = 17;
	static const int FunctionWidget_Y = 85;
	static const int FunctionWidget_WIDTH = 55;
	static const int FunctionWidget_HEIGHT = 18;
	void drawFunctionWidget() {
		draw::printRect(FunctionWidget_X, FunctionWidget_Y, FunctionWidget_WIDTH, FunctionWidget_HEIGHT);
		draw::drawTitle(18, 86, "����˵����");
		draw::drawTitle(19, 88, "������һҳ��q ��һҳ��e");
		draw::drawTitle(20, 88, "��������ƶ���w��s��");
		draw::drawTitle(21, 88, "���ܹ���ƶ������¼�ͷ");
		draw::drawTitle(22, 88, "�س�ȷ��");
		draw::drawTitle(23, 88, "��ݼ���");
		draw::drawTitle(24, 90, "ctrl+F -> ����");
		draw::drawTitle(25, 90, "ctrl+D -> ɾ��");
		draw::drawTitle(26, 90, "ctrl+T -> ˢ��");
		draw::drawTitle(27, 90, "ctrl+S -> ����");
		draw::drawTitle(28, 88, "�˳� ESC");
	}
	/****************************************************************/

	/***********************TCP�������*********************************/
	TcpServer tcpServer;
	thread tcpThread;
	volatile bool isRunning;
	void tcpServe() {			
		while (isRunning) {
			tcpServer.init();
			tcpServer.acceptSocket();
			fstream file("hotel.txt", ios::in);
			char tempInfo[200];
			while (file.getline(tempInfo, 200)) {
				tcpServer.sendMusicInfo(tempInfo);
			}
			tcpServer.sendMusicInfo("EOF");
			file.close();
			tcpServer.close();
		}
		
	}
	/************************************************************/

	
};
