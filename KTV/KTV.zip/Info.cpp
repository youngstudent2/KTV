#include"Info.h"
Info::Info()
{
	tmpState = false;
}
int Info::loadFile(string fileName) {
	fstream file(fileName, ios::in);
	if (!file.is_open())return 0;
	Music music;
	while (file >> music.ID >> music.name >> music.singer >> music.abb >> music.score) {
		for (auto& m : musics) {
			if (m == music)continue;//���ظ�
		}
		if (music.ID < musics.size())music.ID = musics.size();
		musics.push_back(music);
	}
	file.close();
	return 1;
}

int Info::saveInfo(string fileName) {
	if (fileName.find('.') == string::npos)return 0;
	fstream file(fileName, ios::out);
	if (!file.is_open())return 0;
	for (auto &music : musics) {
		file << music.ID << '\t' 
			<< music.name << '\t' 
			<< music.singer << '\t' 
			<< music.abb << '\n';
	}
	file.close();
	return 1;
}

int Info::add(Music m)
{
	if (m.ID == -1)return 0;
	for (auto& music : musics) {
		if (m == music && music.playstate)return 0;
	}
	musics.push_back(m);
	return 1;
}

int Info::musicSearch(string musicName)
{
	tmpRes.clear();
	setTmpState(true);
	for (int i = 0; i < musics.size(); i++) {
		if (musics.at(i).name.find(musicName)!=string::npos || musics.at(i).abb == musicName) {
			tmpRes.push_back(musics.at(i));
		}
	}
	return tmpRes.size(); 
}

int Info::singerSearch(string singerName)
{
	tmpRes.clear();
	setTmpState(true);
	for (int i = 0; i < musics.size(); i++) {
		if (musics.at(i).singer == singerName) {
			tmpRes.push_back(musics.at(i));
		}
	}
	return tmpRes.size();
}

int Info::insert(Music m, int index)
{
	musics.insert(musics.begin() + index, m);
	return 0;
}

Music & Info::createMusic(string name, string singer, string abb)
{
	if (name.empty() || singer.empty() || abb.empty())return *new Music();
	int id = musics.size();
	Music m(name, singer, abb, id);
	return m;
}

int Info::deleteMusic(int index)
{
	if (tmpState) {
		if (index<0 || index>tmpRes.size())return 0;
		int tmpID = tmpRes.at(index).ID;
		tmpRes.erase(tmpRes.begin() + index);
		for (auto& t : tmpRes) {
			if (t.ID > tmpID)t.ID--;
		}
		musics.erase(musics.begin() + tmpID - 1);
		for (vector<Music>::iterator i = musics.begin() + tmpID - 1; i != musics.end();i++) {
			i->ID--;			
		}
	}
	else {
		if (index<0 || index>=musics.size())return 0;
		for (vector<Music>::iterator i = musics.begin() + index + 1; i != musics.end(); i++) {
			i->ID--;
		}
		musics.erase(musics.begin() + index);
	}
	
	return 1;
}

int Info::eraseMusic(int index) {
	if (index < 0 || index >= musics.size())return 0;
	musics.erase(musics.begin() + index);
	return 1;
}

void Info::markMusic(int index, double score)
{
	//��Ҫ�������� ��ʱ������10��
	musics[index].score = (score + musics[index].score * 10) / 11;
}

Music Info::getMusic(int index)
{
	if (index<0 || index>musics_count() - 1) {
		Music m;
		return m;
	}		
	return tmpState ? tmpRes.at(index) : musics.at(index);
}

int Info::musics_count()
{
	return tmpState ? tmpRes.size() : musics.size();
}

void Info::tcpAssist(string MusicInfo)
{
	//work(hotelInfo);
}

void Info::clear()
{
	musics.clear();
}

void Info::setTmpState(bool state)
{
	tmpState = state;
}

void Info::rankMusics()
{
	tmpRes.clear();
	setTmpState(true);
	tmpRes.assign(musics.begin(), musics.end());
	sort(tmpRes.begin(), tmpRes.end(), [](const Music &m, const Music &n)->bool { return m.score > n.score; });
}

void Info::nextMusic(int & playMusic)
{
	//musics[playMusic].playstate = 0;
	musics[++playMusic].playstate = 0;
}

void Info::setMusicState(int index, int state)
{
	musics[index].playstate = state;
}





