#pragma once
#include<fstream>
#include<string>
#include<vector>
#include<iomanip>
#include<algorithm>
using namespace std;
struct Music {
	string name, singer, abb;//������ ������ ��д
	bool playstate;//����״̬
	int ID;//���
	float score;//����
	Music(string n, string s, string a,int ID) {
		name = n;
		singer = s;
		abb = a;
		playstate = 1;
		score = 0.0;
	}
	Music() {
		ID = -1;
	}
	bool operator ==(Music m) {
		return m.name == name && m.singer == singer;
	}
};

class Info {
public:
	Info();
	int loadFile(string fileName);
	int saveInfo(string fileName);
	int add(Music m);
	int musicSearch(string MusicName);
	int singerSearch(string singerName);
	int insert(Music m, int index);
	Music& createMusic(string name, string singer, string abb);
	int deleteMusic(int index);
	Music getMusic(int index);
	int musics_count();
	void tcpAssist(string hotelInfo);
	void clear();
	void setTmpState(bool state);
	void rankMusics();
	void nextMusic(int &playMusic);
	void setMusicState(int index, int state);
	int eraseMusic(int index);
	void markMusic(int index, double score);
private:
	vector<Music> musics;
	vector<Music> tmpRes;
	bool tmpState;
};