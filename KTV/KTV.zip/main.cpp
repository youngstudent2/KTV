#include<iostream>
#include"AdminLayout.h"
#include"ClientLayout.h"
#include"Info.h"
#include"layout1.h"

#pragma comment(lib,"ws2_32.lib")
using namespace std;
int main()
{
	system("mode 150,40");
	layout1 l;
	AdminLayout *admin;
	ClientLayout *client;
	int exec_result;
	/*admin = new AdminLayout;
	if (admin->exec() == 1);
	//break;
	delete admin;
	
	client = new ClientLayout;
	if (client->exec() == 1);
		//break;
	delete client;*/
	
	while (1) {
		int input_times = 0;
		exec_result = -1;
		while (exec_result == -1 && ++input_times < 3)
			exec_result = l.exec();
		if (exec_result == 0) {
			admin = new AdminLayout;
			if (admin->exec() == 1)
				break;
			delete admin;
		}
		else if (exec_result == 1) {
			client = new ClientLayout;
			if (client->exec() == 1)
				break;
			delete client;
		}
		system("cls");
	}
	/**/
	return 0;
}